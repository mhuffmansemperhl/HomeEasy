/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
        scrollRestoration: false,
      },
    
}

module.exports = nextConfig
